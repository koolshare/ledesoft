#!/bin/sh

/koolshare/scripts/anyconnect_config.sh port