#!/bin/sh

sh /jffs/koolshare/aria2/aria2_run.sh stop
rm -rf /jffs/koolshare/aria2
rm -rf /jffs/koolshare/perp/aria2
rm -rf /jffs/koolshare/scripts/aria2_config.sh
rm -rf /jffs/koolshare/webs/Module_aria2.asp

