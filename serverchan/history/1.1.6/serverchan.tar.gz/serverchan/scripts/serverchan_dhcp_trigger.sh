#!/bin/sh

/koolshare/scripts/serverchan_dhcp_trigger