#!/bin/sh

/koolshare/scripts/webrecord_config.sh &
