#!/bin/sh

/koolshare/scripts/transmission_config.sh port