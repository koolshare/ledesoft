#!/bin/sh

/koolshare/scripts/easyexplorer_config.sh port