#! /bin/sh

#start shellinaboxd
$KSROOT/shellinabox/shellinaboxd --css=/jffs/koolshare/shellinabox/white-on-black.css -b
