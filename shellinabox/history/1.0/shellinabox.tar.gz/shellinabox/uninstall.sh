#! /bin/sh

killall shellinaboxd
sleep 1	
rm -rf $KSROOT/webs/res/icon-shellinabox*
rm -rf $KSROOT/webs/Module_shellinabox.asp
rm -rf $KSROOT/shellinabox
