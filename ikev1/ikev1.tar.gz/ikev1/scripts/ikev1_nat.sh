#!/bin/sh

/koolshare/scripts/ikev1_config.sh port