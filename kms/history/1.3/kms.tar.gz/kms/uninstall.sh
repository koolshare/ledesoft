#!/bin/sh
export KSROOT=/jffs/koolshare
rm $KSROOT/bin/vlmcsd
rm $KSROOT/res/icon-kms*
rm $KSROOT/scripts/kms.sh
rm $KSROOT/webs/Module_kms.asp
rm /jffs/etc/dnsmasq.d/kms.conf
