#!/bin/sh
export KSROOT=/koolshare
rm $KSROOT/bin/vlmcsd
rm $KSROOT/webs/res/icon-kms*
rm $KSROOT/scripts/kms.sh
rm $KSROOT/webs/Module_kms.asp
rm $KSROOT/init.d/S97kms.sh
