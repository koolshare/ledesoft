#!/bin/sh

/koolshare/scripts/sqos_config.sh