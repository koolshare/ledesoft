#!/bin/sh

/koolshare/scripts/relay_config.sh